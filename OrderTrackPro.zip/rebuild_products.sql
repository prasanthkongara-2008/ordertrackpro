-- Completely wipe the old messy products table
DROP TABLE IF EXISTS products CASCADE;

-- Create the perfect new products table
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price NUMERIC DEFAULT 0,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Set up the proper security rules
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Products are viewable by everyone" ON products FOR SELECT USING (true);
CREATE POLICY "Store owners can insert products" ON products FOR INSERT WITH CHECK (auth.uid() = store_owner_id);
CREATE POLICY "Store owners can update products" ON products FOR UPDATE USING (auth.uid() = store_owner_id);
CREATE POLICY "Store owners can delete products" ON products FOR DELETE USING (auth.uid() = store_owner_id);

-- Force cache reload
NOTIFY pgrst, 'reload schema';
