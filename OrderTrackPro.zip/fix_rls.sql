DROP POLICY IF EXISTS "Users can manage own businesses" ON businesses;
CREATE POLICY "Users can manage own businesses" ON businesses FOR ALL 
USING (auth.uid() = owner_id) 
WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Users can manage own profile" ON seller_profiles;
CREATE POLICY "Users can manage own profile" ON seller_profiles FOR ALL 
USING (auth.uid() = id) 
WITH CHECK (auth.uid() = id);
