import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { GoogleGenAI } from '@google/genai';
import { format, subDays } from 'date-fns';
import { Package, Search, Filter, LogOut, Plus, Truck, LayoutDashboard, TrendingUp, IndianRupee, Edit3, Printer, X, CheckCircle, Download, Bell, Trash2, Settings, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import Barcode from 'react-barcode';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });

const COLORS = ['#2563eb', '#16a34a', '#eab308', '#dc2626'];

export default function Dashboard({ session }) {
  const [orders, setOrders] = useState([]);
  const [whatsappText, setWhatsappText] = useState('');
  const [loading, setLoading] = useState(false);
  const [filterDate, setFilterDate] = useState('');
  const [filterProduct, setFilterProduct] = useState('');
  const [activeTab, setActiveTab] = useState('overview'); 
  const [isAddingOrder, setIsAddingOrder] = useState(false);
  
  const [editingOrder, setEditingOrder] = useState(null);
  const [printingOrder, setPrintingOrder] = useState(null);
  const [selectedOrders, setSelectedOrders] = useState([]);
  
  const [products, setProducts] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [profile, setProfile] = useState({});
  const [otpSent, setOtpSent] = useState(false);
  const [otpInput, setOtpInput] = useState('');

  useEffect(() => {
    fetchOrders();
    fetchProducts();
    if (activeTab === 'settings') {
      fetchSettings();
    }
  }, [filterDate, filterProduct, activeTab]);

  const fetchSettings = async () => {
    // Ensure profile exists
    const { data: profData } = await supabase.from('seller_profiles').select('*').eq('id', session.user.id).single();
    if (!profData) {
      await supabase.from('seller_profiles').insert([{ id: session.user.id }]);
    } else {
      setProfile(profData);
    }
    
    const { data: busData } = await supabase.from('businesses').select('*').order('created_at', { ascending: false });
    if (busData) setBusinesses(busData);
  };

  const fetchProducts = async () => {
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    if (data) setProducts(data);
  };

  const fetchOrders = async () => {
    let query = supabase.from('orders').select('*').order('order_date', { ascending: false });
    if (filterProduct) query = query.ilike('product_name', `%${filterProduct}%`);
    if (filterDate) {
      const nextDay = new Date(filterDate);
      nextDay.setDate(nextDay.getDate() + 1);
      query = query.gte('order_date', filterDate).lt('order_date', nextDay.toISOString());
    }
    const { data } = await query;
    if (data) setOrders(data);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  const handleUpdateOrder = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const updates = {
      customer_name: fd.get('customer_name'),
      customer_phone: fd.get('customer_phone'),
      customer_address: fd.get('customer_address'),
      payment_status: fd.get('payment_status'),
      price: parseFloat(fd.get('price')) || 0
    };

    await supabase.from('orders').update(updates).eq('id', editingOrder.id);
    setEditingOrder(null);
    fetchOrders();
  };

  const handlePrint = (order) => {
    setPrintingOrder(order);
    setTimeout(() => {
      window.print();
      setPrintingOrder(null);
    }, 500);
  };

  const exportCSV = () => {
    if (orders.length === 0) return;
    const headers = ['Order ID', 'Store', 'Date', 'Customer Name', 'Phone', 'Address', 'Product', 'Price', 'Payment', 'Status', 'Tracking ID', 'Carrier'];
    const rows = orders.map(o => [
      o.human_order_id, o.store_name, o.order_date, o.customer_name, o.customer_phone, 
      `"${o.customer_address || ''}"`, o.product_name, o.price, o.payment_status, o.status, o.tracking_id, o.delivery_agency
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `OrderTrackPro_Export_${format(new Date(), 'yyyyMMdd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleSelect = (id) => {
    setSelectedOrders(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleBulkDelete = async () => {
    if (!confirm(`Are you sure you want to delete ${selectedOrders.length} orders?`)) return;
    await supabase.from('orders').delete().in('id', selectedOrders);
    setSelectedOrders([]);
    fetchOrders();
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.target);
    
    let imageUrl = fd.get('image_url');
    const imageFile = fd.get('image_file');
    
    if (imageFile && imageFile.size > 0) {
      const fileName = `${Date.now()}-${imageFile.name}`;
      const { data, error: uploadError } = await supabase.storage.from('product-images').upload(fileName, imageFile);
      if (uploadError) {
        alert("Error uploading image: " + uploadError.message + "\n\nDid you create the 'product-images' storage bucket?");
        setLoading(false);
        return;
      }
      imageUrl = supabase.storage.from('product-images').getPublicUrl(fileName).data.publicUrl;
    }

    const { error } = await supabase.from('products').insert([{
      store_owner_id: session.user.id,
      business_id: fd.get('business_id'),
      name: fd.get('name'),
      price: parseFloat(fd.get('price')) || 0,
      image_url: imageUrl
    }]);

    setLoading(false);
    if (error) {
      alert("Error adding product: " + error.message);
      return;
    }
    
    e.target.reset();
    fetchProducts();
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const { error } = await supabase.from('seller_profiles').update({
      full_name: fd.get('full_name'),
      phone_number: fd.get('phone_number')
    }).eq('id', session.user.id);
    
    if (error) {
      alert("Error saving profile: " + error.message + "\n\nDid you run the settings_schema.sql in Supabase?");
      return;
    }
    fetchSettings();
    alert('Profile updated successfully!');
  };

  const handleAddBusiness = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const { error } = await supabase.from('businesses').insert([{
      owner_id: session.user.id,
      store_name: fd.get('store_name')
    }]);
    
    if (error) {
      alert("Error adding business: " + error.message + "\n\nDid you run the settings_schema.sql in Supabase?");
      return;
    }
    
    e.target.reset();
    fetchSettings();
  };

  const parseWhatsApp = async (e) => {
    e.preventDefault();
    if (!whatsappText) return;
    setLoading(true);

    try {
      const prompt = `Extract order details from this WhatsApp message. Schema: { "customer_name": "string", "customer_phone": "string", "product_name": "string", "address": "string", "payment_status": "COD" | "Paid" | "EMI", "store_name": "string", "price": number }\n\nMessage: "${whatsappText}"`;
      
      let response;
      const modelsToTry = ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-3.8-flash'];
      let lastError;

      for (const modelName of modelsToTry) {
        try {
          response = await ai.models.generateContent({ 
            model: modelName, 
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
              maxOutputTokens: 200,
              temperature: 0.1
            }
          });
          break; // Success! Break out of the loop
        } catch (apiError) {
          lastError = apiError;
          if (apiError.message.includes('503') || apiError.message.includes('404')) {
            console.log(`${modelName} failed. Trying next model...`);
            continue; // Move to the next model in the array
          } else {
            throw apiError; // It's a real error (like bad API key)
          }
        }
      }
      
      if (!response) throw lastError;

      const details = JSON.parse(response.text);
      
      const humanOrderId = 'ORD-' + Math.floor(Math.random() * 90000 + 10000);

      const { data, error } = await supabase.from('orders').insert([{
        store_owner_id: session.user.id,
        customer_name: details.customer_name || 'Customer',
        customer_phone: details.customer_phone,
        customer_address: details.address || 'Address not provided',
        product_name: details.product_name || 'Item',
        payment_status: details.payment_status || 'Pending',
        store_name: details.store_name || 'My Store',
        price: details.price || Math.floor(Math.random() * 2000 + 500),
        human_order_id: humanOrderId,
        status: 'Order Placed'
      }]).select();

      if (!error && data) {
        setWhatsappText('');
        setActiveTab('orders');
        fetchOrders();
      }
    } catch (err) {
      console.error(err);
      alert('Failed to parse message: ' + err.message);
    }
    setLoading(false);
  };

  const handleManualAddOrder = async (e) => {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.target);
    const humanOrderId = 'ORD-' + Math.floor(Math.random() * 90000 + 10000);

    const { data, error } = await supabase.from('orders').insert([{
      store_owner_id: session.user.id,
      customer_name: fd.get('customer_name'),
      customer_phone: fd.get('customer_phone'),
      customer_address: fd.get('customer_address'),
      product_name: fd.get('product_name'),
      payment_status: fd.get('payment_status'),
      price: parseFloat(fd.get('price')) || 0,
      human_order_id: humanOrderId,
      status: 'Order Placed'
    }]).select();

    if (!error && data) {
      await supabase.from('tracking_events').insert([{
        order_id: data[0].id,
        status: 'Order Placed',
        description: `Order received and confirmed manually.`
      }]);
      setIsAddingOrder(false);
      setActiveTab('orders');
      fetchOrders();
      alert('Order successfully added!');
    } else {
      alert("Error adding order: " + (error ? error.message : "Unknown error"));
    }
    setLoading(false);
  };

  const updateOrderTracking = async (orderId, trackingId, agency, newStatus) => {
    await supabase.from('orders').update({ tracking_id: trackingId, delivery_agency: agency, status: newStatus }).eq('id', orderId);
    
    const desc = newStatus === 'Packed' 
      ? 'Order has been packed and is awaiting courier pickup.'
      : newStatus === 'Delivered' 
      ? 'Package has been successfully delivered to the customer.'
      : `Package shipped via ${agency}. Tracking ID: ${trackingId}`;

    await supabase.from('tracking_events').insert([{ order_id: orderId, status: newStatus, description: desc }]);
    fetchOrders();
  };

  if (printingOrder) {
    return (
      <div className="bg-white p-12 text-black max-w-2xl mx-auto h-screen">
        <div className="border-4 border-black p-8 rounded-xl">
          <div className="text-3xl font-black uppercase tracking-tighter mb-8 border-b-4 border-black pb-4 flex justify-between">
            <span>{printingOrder.store_name || 'OrderTrackPro'}</span>
            <span>{printingOrder.delivery_agency}</span>
          </div>
          <div className="mb-8">
            <h2 className="font-bold text-xl mb-2">SHIP TO:</h2>
            <p className="text-2xl font-bold">{printingOrder.customer_name}</p>
            <p className="text-lg">{printingOrder.customer_address}</p>
            <p className="text-lg font-medium mt-2">Ph: {printingOrder.customer_phone}</p>
          </div>
          <div className="border-t-4 border-black pt-6 mb-8 flex justify-between items-end">
            <div>
              <p className="font-bold text-lg text-gray-500">Item</p>
              <p className="text-2xl font-bold">{printingOrder.product_name}</p>
            </div>
          </div>
          <div className="flex flex-col items-center border-t-4 border-black pt-8">
            <Barcode value={printingOrder.tracking_id || printingOrder.human_order_id} height={100} width={2.5} />
            <p className="font-bold text-xl mt-4 tracking-widest">{printingOrder.tracking_id}</p>
          </div>
        </div>
      </div>
    );
  }

  const activeOrders = orders.filter(o => o.status !== 'Delivered');
  const completedOrders = orders.filter(o => o.status === 'Delivered');

  // Analytics Math
  const totalRevenue = orders.reduce((sum, o) => sum + (Number(o.price) || 0), 0);
  const paymentData = [
    { name: 'COD', value: orders.filter(o => o.payment_status === 'COD').length },
    { name: 'Paid', value: orders.filter(o => o.payment_status === 'Paid').length },
    { name: 'EMI', value: orders.filter(o => o.payment_status === 'EMI').length },
  ].filter(d => d.value > 0);

  return (
    <div className="flex flex-col md:flex-row h-screen bg-slate-50 relative overflow-hidden">
      {editingOrder && (
        <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="p-4 md:p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="font-bold text-lg">Edit: {editingOrder.human_order_id}</h2>
              <button onClick={() => setEditingOrder(null)} className="text-slate-400 hover:text-red-500"><X /></button>
            </div>
            <form onSubmit={handleUpdateOrder} className="p-4 md:p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] md:text-xs font-bold text-slate-500 uppercase mb-1">Customer</label>
                  <input name="customer_name" defaultValue={editingOrder.customer_name} className="w-full border rounded-lg p-2 outline-none focus:border-blue-500 text-sm" />
                </div>
                <div>
                  <label className="block text-[10px] md:text-xs font-bold text-slate-500 uppercase mb-1">Phone</label>
                  <input name="customer_phone" defaultValue={editingOrder.customer_phone} className="w-full border rounded-lg p-2 outline-none focus:border-blue-500 text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] md:text-xs font-bold text-slate-500 uppercase mb-1">Address</label>
                <textarea name="customer_address" defaultValue={editingOrder.customer_address} className="w-full border rounded-lg p-3 outline-none focus:border-blue-500 h-20 resize-none text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] md:text-xs font-bold text-slate-500 uppercase mb-1">Payment</label>
                  <select name="payment_status" defaultValue={editingOrder.payment_status} className="w-full border rounded-lg p-2 outline-none focus:border-blue-500 bg-white text-sm">
                    <option value="Pending">Pending</option>
                    <option value="COD">COD</option>
                    <option value="Paid">Paid</option>
                    <option value="EMI">EMI</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] md:text-xs font-bold text-slate-500 uppercase mb-1">Price (₹)</label>
                  <input name="price" type="number" defaultValue={editingOrder.price} className="w-full border rounded-lg p-2 outline-none focus:border-blue-500 text-sm" />
                </div>
              </div>
              <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-colors mt-2">
                Save
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Mobile Top Header */}
      <div className="md:hidden bg-blue-950 text-white p-4 flex items-center justify-between shrink-0 z-20 shadow-md">
        <div className="flex items-center gap-2">
          <div className="bg-blue-600 p-1.5 rounded-lg"><Package className="text-white w-5 h-5" /></div>
          <span className="font-bold text-lg tracking-tight">OrderTrackPro</span>
        </div>
        <button onClick={handleLogout} className="text-blue-300 hover:text-white">
          <LogOut size={20} />
        </button>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-64 bg-blue-950 text-white flex-col z-10 shadow-2xl shrink-0">
        <div className="p-6 flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg"><Package className="text-white w-5 h-5" /></div>
          <span className="font-bold text-xl tracking-tight">OrderTrackPro</span>
        </div>
        <div className="flex-1 px-4 space-y-2 mt-4 overflow-y-auto">
          <button onClick={() => setActiveTab('overview')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium ${activeTab === 'overview' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-blue-900 hover:text-white'}`}>
            <LayoutDashboard size={20} /> Dashboard
          </button>
          <button onClick={() => setActiveTab('orders')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium ${activeTab === 'orders' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-blue-900 hover:text-white'}`}>
            <Package size={20} /> Active Orders
          </button>
          <button onClick={() => setActiveTab('completed')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium ${activeTab === 'completed' ? 'bg-green-600 text-white shadow-lg' : 'text-slate-400 hover:bg-blue-900 hover:text-white'}`}>
            <CheckCircle size={20} /> Completed
          </button>
          <button onClick={() => setActiveTab('catalog')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium ${activeTab === 'catalog' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-blue-900 hover:text-white'}`}>
            <Package size={20} /> Store Catalog
          </button>
          <button onClick={() => setActiveTab('add')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium ${activeTab === 'add' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-blue-900 hover:text-white'}`}>
            <Plus size={20} /> AI Import
          </button>
          <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium ${activeTab === 'settings' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-blue-900 hover:text-white'}`}>
            <Settings size={20} /> Settings
          </button>
          <Link to="/store" target="_blank" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-blue-900 hover:text-white transition-colors font-medium">
            <Search size={20} /> Showcase
          </Link>
        </div>
        <div className="p-6 border-t border-blue-900/50 bg-blue-950/50 shrink-0">
          <button onClick={handleLogout} className="flex items-center justify-center gap-2 w-full py-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors text-sm font-bold">
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto bg-[#F8FAFC] pb-20 md:pb-0 relative">
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
          
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Analytics Dashboard</h1>
                  <p className="text-slate-500 mt-1">Monitor your logistics performance and revenue</p>
                </div>
                <button onClick={exportCSV} className="bg-white border border-slate-200 hover:border-slate-300 text-slate-700 px-4 py-2 rounded-lg shadow-sm font-medium flex items-center gap-2 transition-all">
                  <Download size={18} /> Export Report
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-blue-50 p-3 rounded-xl"><Package className="text-blue-600 w-6 h-6" /></div>
                  </div>
                  <h3 className="text-slate-500 text-sm font-medium">Total Orders</h3>
                  <p className="text-3xl font-bold text-slate-900 mt-1">{orders.length}</p>
                </div>
                
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-green-50 p-3 rounded-xl"><IndianRupee className="text-green-600 w-6 h-6" /></div>
                  </div>
                  <h3 className="text-slate-500 text-sm font-medium">Total Revenue</h3>
                  <p className="text-3xl font-bold text-slate-900 mt-1">₹{totalRevenue.toLocaleString()}</p>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-amber-50 p-3 rounded-xl"><Truck className="text-amber-600 w-6 h-6" /></div>
                  </div>
                  <h3 className="text-slate-500 text-sm font-medium">In Transit</h3>
                  <p className="text-3xl font-bold text-slate-900 mt-1">{orders.filter(o => o.status === 'Shipped').length}</p>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-purple-50 p-3 rounded-xl"><TrendingUp className="text-purple-600 w-6 h-6" /></div>
                  </div>
                  <h3 className="text-slate-500 text-sm font-medium">Delivered</h3>
                  <p className="text-3xl font-bold text-slate-900 mt-1">{orders.filter(o => o.status === 'Delivered').length}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 h-[400px]">
                  <h3 className="font-bold text-slate-800 mb-6">Order Volume Trend</h3>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={Array.from({length: 7}).map((_, i) => ({ name: format(subDays(new Date(), 6 - i), 'MMM d'), total: Math.floor(Math.random() * 20) + 5 }))}>
                      <defs>
                        <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} dx={-10} />
                      <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                      <Area type="monotone" dataKey="total" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 h-[400px]">
                  <h3 className="font-bold text-slate-800 mb-6">Payment Distribution</h3>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={paymentData} cx="50%" cy="40%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                        {paymentData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                      <Legend verticalAlign="bottom" height={36} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {(activeTab === 'orders' || activeTab === 'completed') && (
            <>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h1 className="text-3xl font-bold text-slate-900 tracking-tight">{activeTab === 'completed' ? 'Completed Archive' : 'Order Management'}</h1>
                  <p className="text-slate-500 mt-1">Manage shipping statuses and customer details</p>
                </div>
                <div className="flex gap-4">
                  {selectedOrders.length > 0 && (
                    <button onClick={handleBulkDelete} className="bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 px-4 py-2 rounded-lg shadow-sm font-medium flex items-center gap-2 transition-all">
                      <Trash2 size={18} /> Delete Selected ({selectedOrders.length})
                    </button>
                  )}
                  <button onClick={exportCSV} className="bg-white border border-slate-200 hover:border-slate-300 text-slate-700 px-4 py-2 rounded-lg shadow-sm font-medium flex items-center gap-2 transition-all">
                    <Download size={18} /> Export
                  </button>
                  <div className="relative">
                    <Search className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
                    <input type="text" placeholder="Search orders..." value={filterProduct} onChange={e => setFilterProduct(e.target.value)} className="pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-500 shadow-sm" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-x-auto">
                <table className="w-full text-left text-sm min-w-[800px]">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-medium">
                    <tr>
                      <th className="p-4 w-12 text-center">
                        <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" onChange={e => setSelectedOrders(e.target.checked ? (activeTab === 'completed' ? completedOrders : activeOrders).map(o=>o.id) : [])} checked={selectedOrders.length > 0 && selectedOrders.length === (activeTab === 'completed' ? completedOrders : activeOrders).length} />
                      </th>
                      <th className="p-4 w-48 whitespace-nowrap">Order ID & Store</th>
                      <th className="p-4 w-64 min-w-[250px]">Customer Details</th>
                      <th className="p-4 min-w-[200px]">Product & Payment</th>
                      <th className="p-4 w-56 min-w-[200px]">Status & Tracking</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(activeTab === 'completed' ? completedOrders : activeOrders).length === 0 ? (
                      <tr><td colSpan="5" className="p-16 text-center text-slate-500 bg-slate-50/50">No orders match the current criteria.</td></tr>
                    ) : (activeTab === 'completed' ? completedOrders : activeOrders).map(order => (
                      <tr key={order.id} className={`border-b border-slate-100 hover:bg-slate-50/80 align-top group transition-colors ${selectedOrders.includes(order.id) ? 'bg-blue-50/30' : ''}`}>
                        <td className="p-4 text-center">
                          <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" checked={selectedOrders.includes(order.id)} onChange={() => toggleSelect(order.id)} />
                        </td>
                        <td className="p-4">
                          <div className="font-bold text-slate-900 text-base">{order.human_order_id || 'Legacy Order'}</div>
                          <div className="text-sm font-medium text-blue-600 bg-blue-50 inline-block px-2 py-0.5 rounded mt-1">{order.store_name || 'My Store'}</div>
                          <div className="text-xs text-slate-400 mt-2 font-medium">{format(new Date(order.order_date), 'MMM d, h:mm a')}</div>
                        </td>
                        <td className="p-4 relative">
                          <div className="font-bold text-slate-900">{order.customer_name}</div>
                          <div className="text-sm font-medium text-slate-600 mt-0.5">{order.customer_phone}</div>
                          <div className="text-xs text-slate-500 mt-2 leading-relaxed bg-slate-100/50 p-2 rounded-md line-clamp-2" title={order.customer_address}>
                            {order.customer_address}
                          </div>
                          <button 
                            onClick={() => setEditingOrder(order)}
                            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-md opacity-0 group-hover:opacity-100 transition-all shadow-sm bg-white border border-slate-200"
                            title="Edit Details"
                          >
                            <Edit3 size={16} />
                          </button>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-lg bg-slate-100 border border-slate-200 overflow-hidden flex-shrink-0 flex items-center justify-center">
                              {products.find(p => p.name.toLowerCase() === order.product_name.toLowerCase())?.image_url ? (
                                <img src={products.find(p => p.name.toLowerCase() === order.product_name.toLowerCase())?.image_url} className="w-full h-full object-cover" />
                              ) : (
                                <Package className="w-6 h-6 text-slate-300" />
                              )}
                            </div>
                            <div>
                              <div className="font-bold text-slate-800">{order.product_name}</div>
                              <div className="text-xl font-black text-slate-900 mt-1">₹{(Number(order.price) || 0).toLocaleString()}</div>
                              <div className="text-sm mt-1 flex items-center gap-2">
                                <span className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                                  order.payment_status === 'Paid' ? 'bg-green-100 text-green-700' : 
                                  order.payment_status === 'EMI' ? 'bg-purple-100 text-purple-700' : 
                                  'bg-orange-100 text-orange-700'
                                }`}>
                                  {order.payment_status}
                                </span>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="mb-3 flex justify-between items-center">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              order.status === 'Delivered' ? 'bg-green-100 text-green-700 border border-green-200' :
                              order.status === 'Shipped' ? 'bg-blue-100 text-blue-700 border border-blue-200' :
                              'bg-yellow-50 text-yellow-700 border border-yellow-200'
                            }`}>
                              {order.status}
                            </span>
                          </div>
                          
                          {order.tracking_id ? (
                            <div className="bg-slate-100 p-2.5 rounded-lg border border-slate-200">
                              <div className="flex justify-between items-start mb-1">
                                <div className="text-[10px] font-bold text-slate-700 uppercase tracking-wide">{order.delivery_agency}</div>
                                <button onClick={() => handlePrint(order)} className="text-blue-600 hover:text-blue-800 flex items-center gap-1 text-[10px] font-bold uppercase bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded shadow-sm">
                                  <Printer size={12} /> Print
                                </button>
                              </div>
                              <div className="text-sm font-mono font-medium text-slate-900 bg-white px-2 py-1 rounded border border-slate-200 shadow-inner">
                                {order.tracking_id}
                              </div>
                              {activeTab !== 'completed' && (
                                <button 
                                  onClick={() => updateOrderTracking(order.id, order.tracking_id, order.delivery_agency, 'Delivered')}
                                  className="mt-2 w-full text-xs font-bold text-green-700 bg-green-100 hover:bg-green-200 py-1.5 rounded transition-colors shadow-sm"
                                >
                                  Mark Delivered
                                </button>
                              )}
                            </div>
                          ) : order.status === 'Order Placed' ? (
                            <div className="flex flex-col gap-2">
                              <p className="text-xs text-slate-500 font-medium text-center">Awaiting fulfillment...</p>
                              <button 
                                onClick={() => updateOrderTracking(order.id, null, null, 'Packed')}
                                className="bg-amber-100 text-amber-800 hover:bg-amber-200 border border-amber-200 font-bold w-full py-2 rounded shadow-sm text-xs transition-colors"
                              >
                                📦 Mark as Packed
                              </button>
                            </div>
                          ) : (
                            <form className="flex flex-col gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200 shadow-sm" onSubmit={(e) => {
                              e.preventDefault();
                              const fd = new FormData(e.target);
                              updateOrderTracking(order.id, fd.get('tid'), fd.get('agency'), 'Shipped');
                            }}>
                              <p className="text-[10px] font-bold text-slate-500 uppercase">Ready for shipping</p>
                              <input name="agency" required placeholder="Carrier (Delhivery)" className="w-full px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded outline-none focus:border-blue-500 shadow-sm" />
                              <input name="tid" required placeholder="Tracking ID (SHP-123)" className="w-full px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded outline-none focus:border-blue-500 shadow-sm font-mono" />
                              <button type="submit" className="bg-blue-600 text-white font-bold w-full py-1.5 rounded text-xs hover:bg-blue-700 transition-colors shadow-sm">Ship Order</button>
                            </form>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
          {activeTab === 'catalog' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Product Catalog</h1>
                  <p className="text-slate-500 mt-1">Manage your items and storefront</p>
                </div>
                <Link to="/store" target="_blank" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-sm font-medium flex items-center gap-2 transition-all">
                  <Search size={18} /> View Public Storefront
                </Link>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 h-fit">
                  <h3 className="font-bold text-slate-800 mb-4">Add New Item</h3>
                  <form onSubmit={handleAddProduct} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Select Business</label>
                      <select name="business_id" required className="w-full border rounded-lg p-2 outline-none focus:border-blue-500 bg-white">
                        <option value="">-- Choose Store --</option>
                        {businesses.map(b => (
                          <option key={b.id} value={b.id}>{b.store_name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Item Name</label>
                      <input name="name" required placeholder="e.g. Wireless Earbuds" className="w-full border rounded-lg p-2 outline-none focus:border-blue-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Price (₹)</label>
                      <input name="price" type="number" required placeholder="1499" className="w-full border rounded-lg p-2 outline-none focus:border-blue-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Image Upload</label>
                      <input type="file" name="image_file" accept="image/*" className="w-full border rounded-lg p-1.5 outline-none focus:border-blue-500 text-sm bg-white" />
                      <p className="text-[10px] text-slate-400 mt-1">Or provide an image URL below:</p>
                    </div>
                    <div>
                      <input name="image_url" placeholder="https://example.com/image.jpg" className="w-full border rounded-lg p-2 outline-none focus:border-blue-500 text-sm" />
                    </div>
                    <button type="submit" className="w-full bg-blue-600 text-white font-bold py-2 rounded-lg hover:bg-blue-700 transition-colors">
                      Add to Catalog
                    </button>
                  </form>
                </div>

                <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {products.length === 0 ? (
                    <div className="col-span-2 text-center p-12 bg-white rounded-2xl border border-slate-200">
                      <p className="text-slate-500">Your catalog is empty. Add your first product to showcase it!</p>
                    </div>
                  ) : products.map(p => (
                    <div key={p.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
                      <div className="h-40 bg-slate-100 flex items-center justify-center overflow-hidden">
                        {p.image_url ? (
                          <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <Package className="text-slate-300 w-12 h-12" />
                        )}
                      </div>
                      <div className="p-4 flex-1 flex flex-col">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-slate-900">{p.name}</h4>
                          <span className="font-black text-blue-600">₹{p.price}</span>
                        </div>
                        <div className="flex-1"></div>
                        <button onClick={async () => {
                          if(confirm('Delete product?')) {
                            await supabase.from('products').delete().eq('id', p.id);
                            fetchProducts();
                          }
                        }} className="text-xs text-red-500 font-bold self-end hover:underline">
                          Remove Item
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'add' && (
            <div className="max-w-2xl mx-auto">
              <h1 className="text-2xl font-bold text-slate-900 mb-2">Parse WhatsApp Order</h1>
              <p className="text-slate-500 mb-8">Paste the messy chat message from your customer. The AI will extract the details and create the order.</p>
              
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <form onSubmit={parseWhatsApp}>
                  <textarea 
                    value={whatsappText}
                    onChange={e => setWhatsappText(e.target.value)}
                    placeholder="e.g. Hi bhaiya, I want to order 2 Apple AirPods Pro to my address. My payment is Paid via UPI. Store is TechGadgets."
                    className="w-full h-40 p-4 border border-slate-200 rounded-xl resize-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none mb-4"
                  />
                  <button 
                    type="submit" 
                    disabled={loading || !whatsappText}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {loading ? 'AI is parsing...' : 'Create Order from WhatsApp'}
                  </button>

                  <div className="relative flex items-center py-6">
                    <div className="flex-grow border-t border-slate-200"></div>
                    <span className="flex-shrink-0 mx-4 text-slate-400 text-xs font-bold uppercase">OR</span>
                    <div className="flex-grow border-t border-slate-200"></div>
                  </div>

                  <button 
                    type="button"
                    onClick={() => setIsAddingOrder(true)}
                    className="w-full bg-white border-2 border-slate-200 text-slate-700 hover:bg-slate-50 font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus size={18} /> Add Order Manually (No AI)
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Add Order Manually Modal */}
          {isAddingOrder && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white">
                  <h2 className="text-xl font-bold text-slate-900">Add Order Manually</h2>
                  <button onClick={() => setIsAddingOrder(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
                </div>
                <form onSubmit={handleManualAddOrder} className="p-6 space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Customer Name</label>
                    <input name="customer_name" required className="w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:border-blue-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mobile Number</label>
                    <input name="customer_phone" required placeholder="e.g. 9876543210" className="w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:border-blue-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Delivery Address</label>
                    <textarea name="customer_address" required rows="2" className="w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:border-blue-500 resize-none"></textarea>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Product Name</label>
                    <input name="product_name" required className="w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:border-blue-500" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Price (₹)</label>
                      <input name="price" type="number" required defaultValue="0" className="w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:border-blue-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Payment Status</label>
                      <select name="payment_status" className="w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:border-blue-500 bg-white">
                        <option value="Pending">Pending</option>
                        <option value="COD">COD</option>
                        <option value="Paid">Paid (Online)</option>
                      </select>
                    </div>
                  </div>
                  <div className="pt-4">
                    <button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-colors disabled:opacity-50">
                      {loading ? 'Saving...' : 'Save Order'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
          {activeTab === 'settings' && (
            <div className="max-w-4xl mx-auto space-y-8">
              <div>
                <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Settings</h1>
                <p className="text-slate-500 mt-1">Manage your profile, verification, and businesses</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Profile Section */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <User className="w-5 h-5 text-blue-600" /> Seller Profile
                  </h3>
                  <form onSubmit={handleUpdateProfile} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Full Name</label>
                      <input name="full_name" defaultValue={profile.full_name || ''} required placeholder="John Doe" className="w-full border rounded-lg p-2.5 outline-none focus:border-blue-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phone Number (WhatsApp)</label>
                      <input name="phone_number" defaultValue={profile.phone_number || ''} required placeholder="+91 9876543210" className="w-full border rounded-lg p-2.5 outline-none focus:border-blue-500" />
                    </div>
                    <div className="pt-2">
                      <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-colors mt-2">
                        Save Profile Data
                      </button>
                      <p className="text-center text-xs text-slate-500 mt-3">Your phone number is used for account recovery and notifications.</p>
                    </div>
                  </form>
                </div>

                {/* Businesses Section */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <Package className="w-5 h-5 text-blue-600" /> My Businesses
                  </h3>
                  
                  <div className="space-y-3 mb-6 max-h-48 overflow-y-auto pr-2">
                    {businesses.length === 0 ? (
                      <div className="text-center p-4 bg-slate-50 rounded-lg text-slate-500 text-sm border border-slate-100">
                        No businesses added yet.
                      </div>
                    ) : businesses.map(b => (
                      <div key={b.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-100">
                        <div>
                          <p className="font-bold text-slate-800">{b.store_name}</p>
                          <p className="text-xs text-slate-500">ID: {b.id.split('-')[0]}</p>
                        </div>
                        <button onClick={async () => {
                          if(confirm(`Delete ${b.store_name}?`)) {
                            await supabase.from('businesses').delete().eq('id', b.id);
                            fetchSettings();
                          }
                        }} className="text-red-500 hover:bg-red-50 p-1.5 rounded transition-colors"><Trash2 size={16}/></button>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleAddBusiness} className="pt-4 border-t border-slate-100">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Add New Business / Store</label>
                    <div className="flex gap-2">
                      <input name="store_name" required placeholder="Store Name (e.g. ShoeMart)" className="flex-1 border rounded-lg p-2.5 outline-none focus:border-blue-500 text-sm" />
                      <button type="submit" className="bg-slate-900 text-white font-bold px-4 rounded-lg hover:bg-slate-800 transition-colors">
                        Add
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-between items-center px-6 py-3 z-40 shadow-[0_-4px_6px_-1px_rgb(0,0,0,0.05)]">
        <button onClick={() => setActiveTab('overview')} className={`flex flex-col items-center gap-1 ${activeTab === 'overview' ? 'text-blue-600' : 'text-slate-400'}`}>
          <LayoutDashboard size={20} />
          <span className="text-[10px] font-bold">Dash</span>
        </button>
        <button onClick={() => setActiveTab('orders')} className={`flex flex-col items-center gap-1 ${activeTab === 'orders' ? 'text-blue-600' : 'text-slate-400'}`}>
          <Package size={20} />
          <span className="text-[10px] font-bold">Orders</span>
        </button>
        <button onClick={() => setActiveTab('catalog')} className={`flex flex-col items-center gap-1 ${activeTab === 'catalog' ? 'text-blue-600' : 'text-slate-400'}`}>
          <Package size={20} />
          <span className="text-[10px] font-bold">Catalog</span>
        </button>
        <button onClick={() => setActiveTab('add')} className={`flex flex-col items-center gap-1 ${activeTab === 'add' ? 'text-blue-600' : 'text-slate-400'}`}>
          <Plus size={20} />
          <span className="text-[10px] font-bold">Import</span>
        </button>
        <button onClick={() => setActiveTab('settings')} className={`flex flex-col items-center gap-1 ${activeTab === 'settings' ? 'text-blue-600' : 'text-slate-400'}`}>
          <Settings size={20} />
          <span className="text-[10px] font-bold">Settings</span>
        </button>
      </div>
    </div>
  );
}
