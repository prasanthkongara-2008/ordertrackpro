require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const { GoogleGenAI } = require('@google/genai');

const app = express();
app.use(cors());
app.use(express.json());

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  'sb_secret_XzOSdy46BTlYHKokbABsXg_urTl10pJ'
);
const ai = new GoogleGenAI({ apiKey: process.env.VITE_GEMINI_API_KEY });

const VERIFY_TOKEN = 'shiptrack_secure_webhook_2026';

// 1. Meta Webhook Verification
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode && token) {
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      console.log('✅ Webhook verified by Meta!');
      res.status(200).send(challenge);
    } else {
      res.sendStatus(403);
    }
  }
});

// 2. Receive Real WhatsApp Messages
app.post('/webhook', async (req, res) => {
  const body = req.body;

  if (body.object) {
    if (body.entry && body.entry[0].changes && body.entry[0].changes[0].value.messages && body.entry[0].changes[0].value.messages[0]) {
      const message = body.entry[0].changes[0].value.messages[0];
      const fromPhone = message.from; // Sender's phone number
      const msgText = message.text.body;
      
      console.log(`📩 Received WhatsApp from ${fromPhone}: ${msgText}`);

      try {
        // AI Parse Order
        const prompt = `Extract order details from this WhatsApp message. Return ONLY a raw JSON object with no markdown formatting. Schema: { "customer_name": "string", "product_name": "string", "address": "string", "payment_status": "COD" | "Paid" | "EMI", "store_name": "string" }\n\nMessage: "${msgText}"`;
        let response;
        const modelsToTry = ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-3.8-flash'];
        let lastError;

        for (const modelName of modelsToTry) {
          try {
            response = await ai.models.generateContent({ 
              model: modelName, 
              contents: prompt,
              config: { 
                responseMimeType: 'application/json',
                maxOutputTokens: 200,
                temperature: 0.1 
              }
            });
            break;
          } catch(e) {
            lastError = e;
            if(e.message.includes('503') || e.message.includes('404')) {
              continue;
            } else {
              throw e;
            }
          }
        }
        if (!response) throw lastError;
        
        const details = JSON.parse(response.text);

        const humanOrderId = 'ORD-' + Math.floor(Math.random() * 90000 + 10000);

        const { data, error } = await supabase.from('orders').insert([{
          customer_name: details.customer_name || 'WhatsApp Customer',
          customer_phone: fromPhone,
          customer_address: details.address || 'Address not provided',
          product_name: details.product_name || 'Unknown Item',
          payment_status: details.payment_status || 'Pending',
          store_name: details.store_name || 'Default Store',
          human_order_id: humanOrderId,
          status: 'Order Placed'
        }]).select();

        if (data) {
          console.log(`✅ Order created in Supabase for ${details.product_name}`);
          
          await supabase.from('tracking_events').insert([{
            order_id: data[0].id,
            status: 'Order Placed',
            description: \`Order received for \${details.store_name || 'your store'} via WhatsApp.\`
          }]);
        }
        if (error) console.error('Supabase Error:', error.message);
      } catch (err) {
        console.error('AI Processing Error:', err.message);
      }
    }
    res.sendStatus(200);
  } else {
    res.sendStatus(404);
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`🚀 WhatsApp Webhook Server listening on port ${PORT}`);
});
