-- Run this in your Supabase SQL Editor to upgrade your Orders table!

ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS customer_address TEXT,
ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'Pending', -- COD, Paid, EMI
ADD COLUMN IF NOT EXISTS store_name TEXT,
ADD COLUMN IF NOT EXISTS human_order_id TEXT,
ADD COLUMN IF NOT EXISTS ticket_number TEXT,
ADD COLUMN IF NOT EXISTS return_status TEXT DEFAULT 'None'; -- None, Requested, Returned

-- Generate a unique readable order ID automatically if missing
UPDATE orders SET human_order_id = 'ORD-' || floor(random() * 90000 + 10000)::text WHERE human_order_id IS NULL;
