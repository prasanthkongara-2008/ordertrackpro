import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Package, ShoppingBag } from 'lucide-react';

export default function Store() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    // In a real app we'd fetch by store_id parameter, but for demo we fetch all
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    if (data) setProducts(data);
    setLoading(false);
  };

  if (loading) return <div className="p-20 text-center">Loading Store...</div>;

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-blue-900 text-white p-8 mb-8 shadow-md">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          <ShoppingBag className="text-yellow-400 w-8 h-8" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">OrderTrackPro Showcase</h1>
            <p className="text-blue-200 mt-1">Official Retail Partner Storefront</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map(p => (
            <div key={p.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden group hover:shadow-lg transition-all">
              <div className="h-56 bg-slate-100 flex items-center justify-center overflow-hidden">
                {p.image_url ? (
                  <img src={p.image_url} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                  <Package className="text-slate-300 w-16 h-16" />
                )}
              </div>
              <div className="p-5">
                <div className="flex justify-between items-start mb-2 gap-2">
                  <h3 className="font-bold text-slate-900 text-lg leading-tight">{p.name}</h3>
                </div>
                <div className="text-xl font-black text-blue-600 mb-3">₹{p.price}</div>
                <button 
                  onClick={() => alert('To order this item, please send us a WhatsApp message with the product name!')} 
                  className="w-full mt-4 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold py-2.5 rounded-xl transition-colors"
                >
                  Order via WhatsApp
                </button>
              </div>
            </div>
          ))}
          {products.length === 0 && (
            <div className="col-span-full p-20 text-center text-slate-500 bg-white rounded-2xl border border-slate-200">
              No products available in this showcase yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
