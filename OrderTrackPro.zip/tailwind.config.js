/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        flipkart: '#2874f0',
        flipkartDark: '#1c5ac1',
        flipkartYellow: '#ff9f00',
      }
    },
  },
  plugins: [],
}
