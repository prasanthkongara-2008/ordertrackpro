-- Create Products Catalog Table
CREATE TABLE IF NOT EXISTS products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC DEFAULT 0,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Allow anyone to read products (for the public storefront)
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Products are viewable by everyone" ON products FOR SELECT USING (true);
CREATE POLICY "Store owners can insert products" ON products FOR INSERT WITH CHECK (auth.uid() = store_owner_id);
CREATE POLICY "Store owners can update products" ON products FOR UPDATE USING (auth.uid() = store_owner_id);
CREATE POLICY "Store owners can delete products" ON products FOR DELETE USING (auth.uid() = store_owner_id);

-- Add image to orders table
ALTER TABLE orders ADD COLUMN IF NOT EXISTS product_image TEXT;
