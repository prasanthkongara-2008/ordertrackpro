-- Create Seller Profiles
CREATE TABLE IF NOT EXISTS seller_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone_number TEXT,
  whatsapp_verified BOOLEAN DEFAULT false,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Businesses (Stores)
CREATE TABLE IF NOT EXISTS businesses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  store_name TEXT NOT NULL,
  store_address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- RLS
ALTER TABLE seller_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own profile" ON seller_profiles FOR ALL USING (auth.uid() = id);

ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view businesses" ON businesses FOR SELECT USING (true);
CREATE POLICY "Users can manage own businesses" ON businesses FOR ALL USING (auth.uid() = owner_id);

-- Insert dummy profile for existing users just in case
INSERT INTO seller_profiles (id) 
SELECT id FROM auth.users ON CONFLICT (id) DO NOTHING;
