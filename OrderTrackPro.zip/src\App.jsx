import { useEffect, useState } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { supabase } from './lib/supabase';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Track from './pages/Track';
import Store from './pages/Store';
import { Package } from 'lucide-react';

function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <Package className="animate-bounce text-blue-600 w-12 h-12" />
    </div>;
  }

  return (
    <Routes>
      <Route path="/track" element={<Track />} />
      <Route path="/login" element={!session ? <Login /> : <Navigate to="/" />} />
      <Route path="/store" element={<Store />} />
      <Route path="/" element={session ? <Dashboard session={session} /> : <Navigate to="/login" />} />
    </Routes>
  );
}

export default App;
