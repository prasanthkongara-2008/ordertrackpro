-- Force add the description column just in case the table existed previously without it
ALTER TABLE products ADD COLUMN IF NOT EXISTS description TEXT;

-- Reload the Supabase API Schema Cache to fix the error
NOTIFY pgrst, 'reload schema';
