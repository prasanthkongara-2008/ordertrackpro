ALTER TABLE products DROP COLUMN IF EXISTS description;
