-- ShipTrack Pro Database Schema

-- Clear existing tables if needed (optional)
DROP TABLE IF EXISTS tracking_events CASCADE;
DROP TABLE IF EXISTS orders CASCADE;

-- 1. Orders Table
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_owner_id UUID REFERENCES auth.users(id), -- Links to the authenticated store owner
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  product_name TEXT NOT NULL,
  order_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  -- Tracking details
  tracking_id TEXT UNIQUE, -- e.g. SHP-123456
  delivery_agency TEXT, -- e.g. BlueDart, Delhivery
  status TEXT DEFAULT 'Order Placed' -- Order Placed, Packed, Shipped, In Transit, Delivered
);

-- 2. Tracking Events (For the public timeline)
CREATE TABLE tracking_events (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  location TEXT,
  description TEXT,
  event_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ENABLE ROW LEVEL SECURITY (RLS)
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE tracking_events ENABLE ROW LEVEL SECURITY;

-- POLICIES
-- Store owners can read and write THEIR OWN orders
CREATE POLICY "Store owners manage their orders" ON orders
  FOR ALL USING (auth.uid() = store_owner_id);

-- Anyone can read an order if they have the tracking_id (we will bypass RLS in the edge function or public query)
CREATE POLICY "Anyone can view order by tracking id" ON orders
  FOR SELECT USING (true);

-- Store owners can manage tracking events for their orders
CREATE POLICY "Store owners manage tracking events" ON tracking_events
  FOR ALL USING (
    EXISTS (SELECT 1 FROM orders WHERE orders.id = tracking_events.order_id AND orders.store_owner_id = auth.uid())
  );

-- Anyone can view tracking events
CREATE POLICY "Anyone can view tracking events" ON tracking_events
  FOR SELECT USING (true);
