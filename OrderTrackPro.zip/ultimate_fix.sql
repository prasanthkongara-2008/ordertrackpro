-- 1. Fix the Bucket & Storage Permissions
INSERT INTO storage.buckets (id, name, public) VALUES ('product-images', 'product-images', true) ON CONFLICT DO NOTHING;

DROP POLICY IF EXISTS "Give public access to product images" ON storage.objects;
CREATE POLICY "Give public access to product images" ON storage.objects FOR ALL USING (bucket_id = 'product-images') WITH CHECK (bucket_id = 'product-images');

-- 2. Force add the missing image_url column
ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url TEXT;

-- 3. Force the API Cache to Reload
NOTIFY pgrst, 'reload schema';
