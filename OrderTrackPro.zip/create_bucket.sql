-- 1. Create the storage bucket
INSERT INTO storage.buckets (id, name, public) 
VALUES ('product-images', 'product-images', true) 
ON CONFLICT (id) DO NOTHING;

-- 2. Allow public access to view images
CREATE POLICY "Public View Access" ON storage.objects 
FOR SELECT USING (bucket_id = 'product-images');

-- 3. Allow authenticated users to upload images
CREATE POLICY "Auth Upload Access" ON storage.objects 
FOR INSERT WITH CHECK (
  bucket_id = 'product-images' AND 
  auth.role() = 'authenticated'
);

-- 4. Allow authenticated users to delete their images
CREATE POLICY "Auth Delete Access" ON storage.objects 
FOR DELETE USING (
  bucket_id = 'product-images' AND 
  auth.role() = 'authenticated'
);
