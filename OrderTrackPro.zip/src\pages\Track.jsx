import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { Search, Package, MapPin, Truck, CheckCircle, PackageOpen, Archive } from 'lucide-react';

export default function Track() {
  const [searchInput, setSearchInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [order, setOrder] = useState(null);
  const [events, setEvents] = useState([]);
  const [error, setError] = useState('');

  const handleTrack = async (e) => {
    e.preventDefault();
    if (!searchInput) return;
    
    setLoading(true);
    setError('');
    setOrder(null);
    setEvents([]);

    // Search by EITHER the Tracking ID or our internal Order ID (e.g. ORD-12345)
    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .select('*')
      .or(`tracking_id.eq.${searchInput},human_order_id.eq.${searchInput}`)
      .single();

    if (orderError || !orderData) {
      setError("We couldn't find a package with that Order ID or Tracking ID.");
      setLoading(false);
      return;
    }

    const { data: eventsData } = await supabase
      .from('tracking_events')
      .select('*')
      .eq('order_id', orderData.id)
      .order('event_date', { ascending: false });

    setOrder(orderData);
    setEvents(eventsData || []);
    setLoading(false);
  };

  const getIconForStatus = (status) => {
    if (status.includes('Placed')) return <PackageOpen className="text-blue-500 w-6 h-6" />;
    if (status.includes('Packed')) return <Archive className="text-amber-500 w-6 h-6" />;
    if (status.includes('Shipped')) return <Package className="text-blue-500 w-6 h-6" />;
    if (status.includes('Transit')) return <Truck className="text-blue-500 w-6 h-6" />;
    if (status.includes('Delivered')) return <CheckCircle className="text-green-500 w-6 h-6" />;
    return <MapPin className="text-slate-500 w-6 h-6" />;
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center pt-20 px-4">
      <div className="mb-8 flex items-center gap-3">
        <div className="bg-blue-600 p-2 rounded-lg">
          <Truck className="text-white w-6 h-6" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">OrderTrackPro Tracker</h1>
      </div>

      <form onSubmit={handleTrack} className="w-full max-w-xl relative mb-12">
        <input 
          type="text" 
          value={searchInput}
          onChange={e => setSearchInput(e.target.value)}
          placeholder="Enter Order ID (ORD-xxx) or Tracking ID" 
          className="w-full pl-6 pr-32 py-4 rounded-full border-2 border-slate-200 shadow-sm text-lg outline-none focus:border-blue-500 transition-colors"
        />
        <button 
          type="submit" 
          disabled={loading}
          className="absolute right-2 top-2 bottom-2 bg-blue-600 hover:bg-blue-700 text-white px-6 rounded-full font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
        >
          {loading ? 'Searching...' : <><Search size={18} /> Track</>}
        </button>
      </form>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-8 w-full max-w-xl text-center border border-red-100">
          {error}
        </div>
      )}

      {order && (
        <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
          <div className="bg-blue-50/50 p-6 border-b border-slate-100">
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="text-sm text-slate-500 uppercase tracking-wide font-semibold mb-1">Tracking ID</p>
                <p className="text-xl font-bold text-slate-900">{order.tracking_id || 'Awaiting Shipment'}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-500 uppercase tracking-wide font-semibold mb-1">Carrier</p>
                <p className="text-lg font-medium text-slate-700">{order.delivery_agency || 'Pending Assignment'}</p>
              </div>
            </div>
            <h2 className="text-lg font-medium text-slate-700 mt-4 border-t border-slate-200 pt-4">
              Item: <span className="font-bold text-slate-900">{order.product_name}</span>
            </h2>
            <p className="text-sm text-slate-500 mt-1">Ordered on {format(new Date(order.order_date), 'MMMM d, yyyy')}</p>
          </div>
          
          <div className="p-8">
            <div className="space-y-8 relative before:absolute before:inset-0 before:ml-6 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-blue-200 before:via-blue-200 before:to-transparent pb-4">
              {events.map((ev, idx) => (
                <div key={ev.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full border-4 border-white bg-blue-50 text-blue-500 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    {getIconForStatus(ev.status)}
                  </div>
                  
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-3rem)] p-5 rounded-2xl bg-white shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] border border-slate-100">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-bold text-slate-900 text-lg">{ev.status}</h3>
                      <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                        {format(new Date(ev.event_date), 'MMM d, h:mm a')}
                      </span>
                    </div>
                    <p className="text-slate-600 text-sm">{ev.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
