ALTER TABLE orders ADD COLUMN IF NOT EXISTS price NUMERIC DEFAULT 0;
UPDATE orders SET price = floor(random() * 4000 + 500) WHERE price = 0 OR price IS NULL;
